import sys
from Ui_untitled import Ui
from PySide6.QtCore import *
from PySide6.QtGui import *
from PySide6.QtWidgets import *
import SimpleITK as sitk
import numpy as np                          
import PySide6
import os
import vtkmodules.all as vtk

#配置环境变量
dirname = os.path.dirname(PySide6.__file__)
plugin_path = os.path.join(dirname, 'plugins', 'platforms')
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = plugin_path
print(plugin_path)


class Function(Ui):#继承UI
    def __init__(self):#构造函数
        super().__init__()#首先调用父类中的__init__()函数，括号里不用写self，但函数如果有其他参数也要写进去，__init__()也可以是其他父类中的函数
        self.pushButton_path.clicked.connect(self.open_file)#设置打开文件按钮信号
        self.pushButton_show3D.clicked.connect(self.show_3D)#体渲染信号
        self.pushButton_data.clicked.connect(self.show_data)#显示图像数据
        self.pushButton_max3D.clicked.connect(self.min_3D)#放大渲染窗口
        self.pushButton_min3D.clicked.connect(self.max_3D)#缩小大渲染窗口
        self.combo_giren.currentIndexChanged.connect(self.change_section)#下拉列表框切换剖面
        self.pushButton_key.clicked.connect(self.key_text)#显示快捷键
        self.pushButton_output.clicked.connect(self.output_nii)#导入nii


    def open_file(self):#打开文件槽函数
        global open,image,image_array,x_spacing,y_spacing,z_spacing,tra,cor,sag,repeats,image_path#全局变量，在函数内声明这个变量可供其他函数调用
        print(open)
        self.listWidget.addItem("图像读取中......") #大文件打开较慢，在listwidget里提示正在加载
        self.listWidget.item(0).setFont(QFont('Times', 15, QFont.Black))#字体字号加粗
        self.listWidget.item(0).setForeground(QColor('blue'))#字体颜色

        open = QFileDialog.getExistingDirectory(self,"选取文件夹")#打开文件夹并返回文件夹路径，(归属于哪个窗口，弹出子窗口名称),后面可以再加一个参数如("C:\\")默认子窗口弹出位置为C盘)

        reader = sitk.ImageSeriesReader()#sitk读取dicom图像类
        image_path = reader.GetGDCMSeriesFileNames(open)#获取文件夹内所有切片路径 
        reader.SetFileNames(image_path)#通过上面获取到的路径来读取每一张dcm图片
        image = reader.Execute()#得到对应的3D图像
        
        image_array = sitk.GetArrayFromImage(image)#把sitk读取到的dicom文件转为np数组   

        tra = np.rot90 (image_array, k=1, axes=(1,2)) #旋转 
        self.pg_tra.setImage(tra)#用pyqtgraph显示这个数组
        initial_index = tra.shape[0]//2#获取层数，除以二向下取整得到中间层数
        self.pg_tra.setCurrentIndex(initial_index)#从中间层数开始显示
        
        sag_1 = image_array.transpose(2,0,1)
        #把数组从轴位改为矢状位，，也就是把之前的(0,1,2)的维度改为(2,0,1),改完后的shape是(512,36,512)，显示出来是窄的，需要把这个36变为512附近显示才正常
        #transpose是转置的意思，T也是转置，但代表的是完全颠倒，T在三维上等于transpose(2,1,0),要指定轴顺序就不能用T
        #还有一个转置函数是swapaxes，swapaxes(0,1)意思就是原数组的0轴和1轴对调
        x_spacing,y_spacing,z_spacing = image.GetSpacing()#获取spacing
        repeats = int(z_spacing/x_spacing)#计算出插值需要复制的倍数
        sag_2 = np.repeat(sag_1, repeats, axis=1)#这里做一个插值操作，这是一个单纯的复制，第二个参数为的次数，第三个参数为需要复制的那个维度，0是最高维度，1是第二维度，2是第一维度
        sag = np.rot90 (sag_2, k=3, axes=(1,2))
        #设置旋转角度，k值决定，k也可以为负数，axes定义的是用于旋转的平面，正常拍摄体位下，把axes改为(0,1)，k=1，则显示矢状位，若原图像就是倒的那么有相应变化
        #三维空间中，0是最高维z轴，1是x轴，2是y轴，其实这个函数等于image_array.transpose(0,2,1),对调x轴和y轴实现旋转90°，但转置只是针对轴的调换，解决不了坐标由正变为负数旋转180度的问题
        #所以其实np.rot90这个函数就可以完全解决得到矢状位冠状位的问题了，但这不完全是MPR
        self.pg_sag.setImage(sag)#用pyqtgraph显示这个数组
        initial_index = sag.shape[0]//2#获取层数，除以二向下取整得到中间层数
        self.pg_sag.setCurrentIndex(initial_index)#从中间层数开始显示

        cor_1 = image_array.transpose(1,0,2)#转置
        cor_2 = np.repeat(cor_1, repeats, axis=1)#插值
        cor = np.rot90 (cor_2, k=3, axes=(1,2))#旋转 
        self.pg_cor.setImage(cor)#显示
        initial_index = sag_2.shape[0]//2#获取层数，除以二向下取整得到中间层数
        self.pg_cor.setCurrentIndex(initial_index)#从中间层数开始显示
       
        self.listWidget.clear()#清楚列表框加载过程中的文字显示


    def show_3D(self):
        reader = vtk.vtkDICOMImageReader()#VTK的dicom读取器
        reader.SetDirectoryName(open)#选择文件        
        #volume_mapper = vtk.vtkFixedPointVolumeRayCastMapper()#CPU体绘制映射器
        volume_mapper = vtk.vtkGPUVolumeRayCastMapper()#GPU体绘制映射器
        volume_mapper.SetInputConnection(reader.GetOutputPort())#reader连接到映射器

        volume_color = vtk.vtkColorTransferFunction()#颜色传递函数,是一个分段函数,RGB和下面的A都是一个0-1的值
        volume_color.AddRGBPoint(0, 0.0, 0, 0.0)#起点
        volume_color.AddRGBPoint(500, 240.0 / 255.0, 184.0 / 255.0, 160.0 / 255.0)#断点
        volume_color.AddRGBPoint(1000, 240.0 / 255.0, 184.0 / 255.0, 160.0 / 255.0)#断点
        volume_color.AddRGBPoint(1150, 1.0, 1.0, 240.0 / 255.0)#终点  

        volume_scalar_opacity = vtk.vtkPiecewiseFunction()#不透明度传递函数，也是一个分段函数
        volume_scalar_opacity.AddPoint(0, 0.00)#起点
        volume_scalar_opacity.AddPoint(500, 0.15)#断点
        volume_scalar_opacity.AddPoint(1000, 0.15)#断点
        volume_scalar_opacity.AddPoint(1150, 0.85)#终点

        volume_property = vtk.vtkVolumeProperty()#把设置好的函数加入到到体渲染属性中
        volume_property.SetColor(volume_color)#颜色传递函数
        volume_property.SetScalarOpacity(volume_scalar_opacity)#不透明度传递函数
        volume_property.SetInterpolationTypeToLinear()#设置体渲染器的插值类型为线性插值
        volume_property.ShadeOn()#开启体渲染器的阴影效果
        volume_property.SetAmbient(0.4)#控制渲染的图像的亮度，从而调节渲染的图像的明暗程度
        volume_property.SetDiffuse(0.6)#控制渲染的图像的漫反射程度，从而调节渲染的图像的颜色和纹理
        volume_property.SetSpecular(0.2)#控制渲染的图像的镜面反射程度，从而调节渲染的图像的高光和反光效果

        volume = vtk.vtkVolume()#演员
        volume.SetMapper(volume_mapper)#映射器加入演员
        volume.SetProperty(volume_property)#体绘制参数加入演员

        ren = vtk.vtkRenderer()#渲染器
        ren.AddViewProp(volume)#演员加入渲染器
        
        camera = ren.GetActiveCamera()#摄像机
        c = volume.GetCenter()#用于获取体积的中心点，可以用来获取体积的位置和大小，从而控制渲染的图像的位置和尺寸
        camera.SetViewUp(0, 0, -1)#设置摄像机的视角
        camera.SetPosition(c[0], c[1] - 400, c[2])#用于设置摄像机的位置
        camera.SetFocalPoint(c[0], c[1], c[2])#设置摄像机的焦点
        camera.Azimuth(30.0)#设置摄像机的方位角
        camera.Elevation(30.0)#设置摄像机的仰角

        self.pg_3D.GetRenderWindow().AddRenderer(ren)#交互器
        self.pg_3D.Initialize()#初始化VTK系统
        self.pg_3D.Start()#启动VTK
    

    def change_section(self):#获取下拉列表框信号并发送给相应的槽函数
        global index#全局变量
        index = self.combo_giren.currentIndex()#获取下拉列表框信号
        if index==1:#如果下拉列表框index==1则把信号发射给image_grien_tra
            self.slider_giren.valueChanged.connect(self.image_grien_tra)
        if index==2:
            self.slider_giren.valueChanged.connect(self.image_grien_cor)
        if index==3:
            self.slider_giren.valueChanged.connect(self.image_grien_sag)

    
    def image_grien_tra(self):#横断位旋转
        if index ==1:
            value = self.slider_giren.value()#获取滑块值
            if value==0:
                rot = np.rot90 (tra, k=0, axes=(1,2))#旋转
                self.pg_tra.setImage(rot)#显示
                initial_index = tra.shape[0]//2#获取中间层面
                self.pg_tra.setCurrentIndex(initial_index)#中间层面显示
            elif value==1:
                rot = np.rot90 (tra, k=1, axes=(1,2)) 
                self.pg_tra.setImage(rot)
                initial_index = tra.shape[0]//2
                self.pg_tra.setCurrentIndex(initial_index)
            elif value==2:
                rot = np.rot90 (tra, k=2, axes=(1,2)) 
                self.pg_tra.setImage(rot)
                initial_index = tra.shape[0]//2
                self.pg_tra.setCurrentIndex(initial_index)
            elif value==3:
                rot = np.rot90 (tra, k=3, axes=(1,2)) 
                self.pg_tra.setImage(rot)
                initial_index = tra.shape[0]//2
                self.pg_tra.setCurrentIndex(initial_index)
    def image_grien_cor(self):
        if index ==2:
            value = self.slider_giren.value()
            if value==0:
                rot = np.rot90 (cor, k=0, axes=(1,2))
                self.pg_cor.setImage(rot) 
                initial_index = cor.shape[0]//2
                self.pg_cor.setCurrentIndex(initial_index)
            elif value==1:
                rot = np.rot90 (cor, k=1, axes=(1,2)) 
                self.pg_cor.setImage(rot)
                initial_index = cor.shape[0]//2
                self.pg_cor.setCurrentIndex(initial_index)
            elif value==2:
                rot = np.rot90 (cor, k=2, axes=(1,2)) 
                self.pg_cor.setImage(rot)
                initial_index = cor.shape[0]//2
                self.pg_cor.setCurrentIndex(initial_index)
            elif value==3:
                rot = np.rot90 (cor, k=3, axes=(1,2)) 
                self.pg_cor.setImage(rot)
                initial_index = cor.shape[0]//2
                self.pg_cor.setCurrentIndex(initial_index)
    def image_grien_sag(self):
        if index ==3:
            value = self.slider_giren.value()
            if value==0:
                rot = np.rot90 (sag, k=0, axes=(1,2))
                self.pg_sag.setImage(rot) 
                initial_index = sag.shape[0]//2
                self.pg_sag.setCurrentIndex(initial_index)
            elif value==1:
                rot = np.rot90 (sag, k=1, axes=(1,2)) 
                self.pg_sag.setImage(rot)
                initial_index = sag.shape[0]//2
                self.pg_sag.setCurrentIndex(initial_index)
            elif value==2:
                rot = np.rot90 (sag, k=2, axes=(1,2)) 
                self.pg_sag.setImage(rot)
                initial_index = sag.shape[0]//2
                self.pg_sag.setCurrentIndex(initial_index)
            elif value==3:
                rot = np.rot90 (sag, k=3, axes=(1,2)) 
                self.pg_sag.setImage(rot)
                initial_index = sag.shape[0]//2
                self.pg_sag.setCurrentIndex(initial_index)


    def show_data(self):#显示图像信息
        self.listWidget.clear()#清除其他在qlistwidget里的内容
        series_0 = image_path[0]#选择最前面那张dicom图像来获取信息
        data_Size = "图像尺寸(Size):" + str(image_array.shape[2]) + "*" + str(image_array.shape[1]) + "*" + str(image_array.shape[0])  
        data_Spacing = "体素尺寸(Spacing):" + str(x_spacing) + "*" + str(y_spacing) + "*" + str(z_spacing) 
        data_Origin = "图像原点(Origin):" + str(image.GetOrigin())
        data_name = "患者姓名:" + str(sitk.ReadImage(series_0).GetMetaData("0010|0010"))
        data_ID = "患者ID:" + str(sitk.ReadImage(series_0).GetMetaData("0010|0020"))
        data_Modality = "检查模态:" + str(sitk.ReadImage(series_0).GetMetaData("0008|0060"))
        data_Thickness = "层厚:" + str(sitk.ReadImage(series_0).GetMetaData("0018|0050"))
        data_BeTween = "层间距:" + str(sitk.ReadImage(series_0).GetMetaData("0018|0088"))
        self.listWidget.addItem(data_Size)
        self.listWidget.addItem("")
        self.listWidget.addItem(data_Spacing)
        self.listWidget.addItem("")
        self.listWidget.addItem(data_Origin)
        self.listWidget.addItem("")
        self.listWidget.addItem(data_name)
        self.listWidget.addItem("")
        self.listWidget.addItem(data_ID)
        self.listWidget.addItem("")
        self.listWidget.addItem(data_Modality)
        self.listWidget.addItem("")
        self.listWidget.addItem(data_Thickness)
        self.listWidget.addItem("")
        self.listWidget.addItem(data_BeTween)
        
    def key_text(self):#显示快捷键信息
        self.listWidget.clear()
        self.listWidget.addItem("1:键盘左右键换层")
        self.listWidget.addItem("")
        self.listWidget.addItem("2:鼠标双击放大/缩小窗口")
        self.listWidget.addItem("")
        self.listWidget.addItem("3:按住鼠标左键拖动图像")
        self.listWidget.addItem("")
        self.listWidget.addItem("4:鼠标中键滑动放大/缩小图像")

    #直接重写双击事件，双击放大/缩小渲染窗口外的其他三个窗口
    def mouseDoubleClickEvent(self,QMouseEvent): 
        #获取鼠标位置
        x = QMouseEvent.x()
        y = QMouseEvent.y()
        
        #获取控件的高
        h_tra = self.pg_tra.height()
        h_sag = self.pg_sag.height()
        h_cor = self.pg_cor.height()
        
        #获取窗口大小
        w = self.width()
        h = self.height()
        
        #放大窗口
        if int(w*0.125)<x<int(w*0.5625) and 0<y<int(h*0.5) and h_cor<int(h*0.6) and h_tra<int(h*0.6) and h_sag<int(h*0.6):#鼠标所在位置条件
            self.pg_cor.hide()#隐藏控件，如果不隐藏，下面设置控件比例的时候不能设为0
            self.pg_sag.hide()
            self.pg_3D.hide()
            self.layout4.setStretch(0, 0)#重置控件比例
            self.layout4.setStretch(1, 1)
            self.layout4.setStretch(2, 0)
        if int(w*0.125)<x<int(w*0.5625) and y>int(h*0.5) and h_cor<int(h*0.6) and h_tra<int(h*0.6) and h_sag<int(h*0.6):
            self.pg_tra.hide()
            self.pg_3D.hide()
            self.pg_sag.hide()
            self.layout4.setStretch(0, 0)
            self.layout4.setStretch(1, 1)
            self.layout4.setStretch(2, 0) 
        if x>int(w*0.5625) and y>int(h*0.5) and h_cor<int(h*0.6) and h_tra<int(h*0.6) and h_sag<int(h*0.6):
            self.pg_cor.hide()
            self.pg_3D.hide()
            self.pg_tra.hide()
            self.layout4.setStretch(0, 0)
            self.layout4.setStretch(1, 0)
            self.layout4.setStretch(2, 1)

        #缩小窗口
        if h_tra>int(h*0.5):
            self.pg_cor.show()#显示刚才隐藏的控件
            self.pg_3D.show()
            self.pg_sag.show()
            self.layout4.setStretch(0, 2)
            self.layout4.setStretch(1, 7)
            self.layout4.setStretch(2, 7)
        if h_cor>int(h*0.5):
            self.pg_tra.show()
            self.pg_3D.show()
            self.pg_sag.show()
            self.layout4.setStretch(0, 2)
            self.layout4.setStretch(1, 7)
            self.layout4.setStretch(2, 7) 
        if h_sag>int(h*0.5):
            self.pg_tra.show()
            self.pg_3D.show()
            self.pg_cor.show()
            self.layout4.setStretch(0, 2)
            self.layout4.setStretch(1, 7)
            self.layout4.setStretch(2, 7)

    #放大渲染窗口
    def min_3D(self):#渲染窗口与其他窗口的双击事件不一样，需要重新设置
        self.pg_cor.hide()
        self.pg_sag.hide()
        self.pg_tra.hide()
        self.layout4.setStretch(0, 0)
        self.layout4.setStretch(1, 0)
        self.layout4.setStretch(2, 1)
    #缩小渲染窗口
    def max_3D(self):
        self.pg_tra.show()
        self.pg_sag.show()
        self.pg_cor.show()
        self.layout4.setStretch(0, 2)
        self.layout4.setStretch(1, 7)
        self.layout4.setStretch(2, 7)
            
    def output_nii(self):#导出nii文件
        filepath, type = QFileDialog.getSaveFileName(self, "保存文件", "new", "*.nii")
        sitk.WriteImage(image,filepath)

if __name__ == "__main__":
    vtk.vtkOutputWindow.SetGlobalWarningDisplay(0)#为了防止跳出vtkoutputwindow窗口
    app = QApplication(sys.argv)#应用程序本身
    win = Function()#实例化主程序
    win.show()#显示主程序
    sys.exit(app.exec())#启动事件循环
    
    



