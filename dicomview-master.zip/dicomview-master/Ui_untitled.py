from PySide6.QtCore import *
from PySide6.QtGui import *
from PySide6.QtWidgets import *
import pyqtgraph as pg 
import sys
from vtkmodules.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor#VTK嵌入pyqt需要借助这个控件

class Ui(QWidget):#继承QWidget
    def __init__(self):
        super().__init__()
        self.initUI()
        

    def initUI(self):
        #设置窗口窗口属性
        self.setWindowTitle("DICOM图像查看")
        self.resize(1600,1000)
        self.move(500,100)
        
        #实例化各个控件并设置其属性
        self.pushButton_path = QPushButton("选择文件")
        self.pushButton_show3D = QPushButton("显示体渲染")
        self.pushButton_max3D = QPushButton("放大渲染窗口")
        self.pushButton_min3D = QPushButton("缩小渲染窗口")
        self.pushButton_data =  QPushButton("显示数据信息")
        self.pushButton_key = QPushButton("显示快捷操作")
        self.pushButton_output = QPushButton("导出nift")

        self.slider_giren = QSlider(Qt.Horizontal)
        self.slider_giren.setMinimum(0)
        self.slider_giren.setMaximum(3)
        self.slider_giren.setTickInterval(1)
        self.slider_giren.setSingleStep(1)
        self.slider_giren.setValue(0)
        self.slider_giren.setTickPosition(QSlider.TicksBelow)
        
        self.combo_giren = QComboBox()
        self.combo_giren.addItem("选择剖面")
        self.combo_giren.addItem("横断位")
        self.combo_giren.addItem("冠状位")
        self.combo_giren.addItem("矢状位")

        self.pg_3D = QVTKRenderWindowInteractor()
        self.pg_tra = pg.ImageView()
        self.pg_sag = pg.ImageView()
        self.pg_cor = pg.ImageView()
        self.listWidget = QListWidget()
        
        self.label_giren = QLabel("旋转图像")
        self.label_giren.setFont(QFont("Roman times",12))

        self.label_none_1 = QLabel("")
        self.label_none_2 = QLabel("")
        self.label_none_3 = QLabel("")
        self.label_none_4 = QLabel("")
        self.label_none_5 = QLabel("")

        #设置控件样式
        self.pushButton_path.setStyleSheet('background-color: rgb(192, 192, 192);border-radius: 10px; border: 5px groove gray;border-style: outset;')
        self.pushButton_show3D.setStyleSheet('background-color: rgb(192, 192, 192);border-radius: 10px; border: 5px groove gray;border-style: outset;')
        self.pushButton_data.setStyleSheet('background-color: rgb(192, 192, 192);border-radius: 10px; border: 5px groove gray;border-style: outset;')
        self.pushButton_key.setStyleSheet('background-color: rgb(192, 192, 192);border-radius: 10px; border: 5px groove gray;border-style: outset;')
        self.pushButton_max3D.setStyleSheet('background-color: rgb(192, 192, 192);border-radius: 10px; border: 2px groove gray;border-style: outset;')
        self.pushButton_min3D.setStyleSheet('background-color: rgb(192, 192, 192);border-radius: 10px; border: 2px groove gray;border-style: outset;')
        self.label_giren.setStyleSheet('background-color: rgb(192, 192, 192);border-radius: 10px; border: 5px groove gray;border-style: outset;')
        self.combo_giren.setStyleSheet('background-color: rgb(192, 192, 192); border: 2px groove gray;border-style: outset;')
        self.slider_giren.setStyleSheet('background-color: rgb(192, 192, 192);border: 2px groove gray;border-style: outset;')
        self.listWidget.setStyleSheet('background-color: rgb(192, 192, 192);border: 3px groove gray;border-style: inset;')
        self.pushButton_output.setStyleSheet('background-color: rgb(192, 192, 192);border-radius: 10px; border: 5px groove gray;border-style: outset;')
        #'background-color: rgb(192, 192, 192);'设置背景颜色
        #'border-radius: 10px;'设置倒角程度
        #'border: 5px groove gray'设置突出程度
        #'border-style: outset;'设置是突入inset还是突出outset

        #布局
        #QHBoxLayout 水平布局
        #QVBoxLayout 垂直布局
        #布局中加入控件用addWidget，布局中加入布局用addLayout
        self.layout_3Dsize = QHBoxLayout()
        self.layout_3Dsize.addWidget(self.pushButton_max3D)
        self.layout_3Dsize.addWidget(self.pushButton_min3D)

        self.show_text = QHBoxLayout()
        self.show_text.addWidget(self.pushButton_data)
        self.show_text.addWidget(self.pushButton_key)

        self.giren = QHBoxLayout()
        self.giren.addWidget(self.label_giren)
        self.giren.addWidget(self.combo_giren)

        self.layout1 = QVBoxLayout()
        self.layout1.addWidget(self.pushButton_path)
        self.layout1.addWidget(self.label_none_1)
        self.layout1.addWidget(self.pushButton_show3D)
        self.layout1.addLayout(self.layout_3Dsize)
        self.layout1.addWidget(self.label_none_2)
        self.layout1.addLayout(self.giren)
        self.layout1.addWidget(self.slider_giren)
        self.layout1.addWidget(self.label_none_3)
        self.layout1.addLayout(self.show_text)
        self.layout1.addWidget(self.listWidget)
        self.layout1.addWidget(self.label_none_4)
        self.layout1.addWidget(self.pushButton_output)
        self.layout1.addWidget(self.label_none_5)
        
        self.layout2 = QVBoxLayout()
        self.layout2.addWidget(self.pg_tra)
        self.layout2.addWidget(self.pg_cor)
        
        self.layout3 = QVBoxLayout()
        self.layout3.addWidget(self.pg_3D)
        self.layout3.addWidget(self.pg_sag)
        self.layout3.setStretch(0, 1)
        self.layout3.setStretch(1, 1)
        
        self.layout4 = QHBoxLayout(self)
        self.layout4.addLayout(self.layout1)
        self.layout4.addLayout(self.layout2)
        self.layout4.addLayout(self.layout3)
        self.layout4.setStretch(0, 2)
        self.layout4.setStretch(1, 7)
        self.layout4.setStretch(2, 7)
        

if __name__ == "__main__":#当在本界面运行程序的时候__name__是等于"__main__"的，可以直接运行，当在别的文件调用此文件时候，__name__就不等于"__main__"，以下代码则不运行
    app = QApplication(sys.argv)
    win = Ui()
    win.show()
    sys.exit(app.exec())
       
#应用程序本身
#实例化主程序
#显示主程序
#启动事件循环








